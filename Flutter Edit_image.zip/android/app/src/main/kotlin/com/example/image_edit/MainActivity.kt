package com.example.image_edit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
